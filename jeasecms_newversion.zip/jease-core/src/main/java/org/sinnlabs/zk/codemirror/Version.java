/** 
 * CodeMirror.java
 * 
 * Copyright (C) 2015 Sinnlabs LTD. All Rights Reserved.
 * 
 * {{IS_RIGHT
 *   This program is distributed under LGPL Version 2.1 in the hope that
 *   it will be useful, but WITHOUT ANY WARRANTY.
 * }}IS_RIGHT
 */
package org.sinnlabs.zk.codemirror;

/**
 * Language addon version
 * @author peter.liverovsky
 *
 */
public class Version {
	public static final String UID = "0.0.1";
}
